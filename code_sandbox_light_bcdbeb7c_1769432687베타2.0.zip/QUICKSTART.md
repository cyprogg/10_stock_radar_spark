# 🚀 Quick Start Guide

## 전체 실행 순서

### 1️⃣ 백엔드 API 서버 실행

```bash
cd backend
pip install -r requirements.txt
python server.py
```

**실행 확인:**
- 브라우저에서 `http://127.0.0.1:8125` 접속
- `{"service":"Decision Stream API","version":"1.0.0","status":"running"}` 확인

---

### 2️⃣ 프론트엔드 열기

```bash
# 프로젝트 루트에서
open index.html
# 또는 브라우저에서 직접 열기
```

**확인 사항:**
- Market Regime 카드에 "RISK_ON" 표시
- Sector Heatmap에 5개 섹터 표시
- "방산" 또는 "에너지" 섹터 클릭 시 Stock Funnel 표시

---

### 3️⃣ 월간 스크리너 실행 (선택사항)

```bash
cd screener
pip install -r requirements.txt
python main_monthly.py
```

**출력 확인:**
```
✅ Wrote candidates: data/output/candidates_202601.csv (n=3)

=== Top Candidates ===
  ticker            name  score_total  entry_price
0  012450  한화에어로스페이스         82      52500.0
1  079550      LIG넥스원         78      48000.0
2  010120        LS전선         72      35000.0
```

---

## 📁 프로젝트 구조

```
decision-stream/
├── index.html                    # 통합 프론트엔드
├── README.md                     # 프로젝트 문서
├── QUICKSTART.md                 # 이 파일
│
├── backend/
│   ├── server.py                 # FastAPI 서버
│   └── requirements.txt
│
├── screener/
│   ├── main_monthly.py           # 월간 스크리너
│   ├── requirements.txt
│   └── data/
│       ├── raw/                  # 표준 CSV
│       │   ├── universe.csv
│       │   ├── news_events.csv
│       │   ├── prices_daily.csv
│       │   ├── flows_daily.csv
│       │   └── index_kospi.csv
│       ├── hts_raw/              # HTS 원본 CSV
│       │   ├── prices/
│       │   └── flows/
│       └── output/               # 스크리너 결과
│           └── candidates_YYYYMM.csv
│
└── tools/
    ├── convert_hts_prices.py     # 일봉 변환
    └── convert_hts_flows.py      # 수급 변환
```

---

## 🔧 설정 변경

### 사용자 플랜 변경 (FREE/PRO/ELITE)

**index.html** 수정:
```javascript
// 12번 줄
const USER_PLAN = "FREE";  // FREE | PRO | ELITE
```

- **FREE**: Market Intelligence까지만 (Trade Plan 숨김)
- **PRO**: Trade Plan 표시
- **ELITE**: Trade Plan + ELITE 최종 검증 표시

---

### API 키 변경

**backend/server.py** 수정:
```python
# 23번 줄
VALID_API_KEY = "ds-test-2026"
```

**index.html** 수정:
```javascript
// 168번 줄
const ACCESS_KEY = "ds-test-2026";
```

---

## 📊 HTS CSV 데이터 수집 가이드

### 키움증권 (영웅문4)

#### 1. 일봉 시세
1. HTS 실행 → `0600` 입력
2. "일별주가" 화면 진입
3. 종목 선택 (전체 또는 관심종목)
4. 기간: 최근 6개월 이상
5. 하단 `[파일저장]` → `CSV` 선택
6. 저장 위치: `screener/data/hts_raw/prices/`

#### 2. 수급
1. HTS 실행 → `0450` 입력
2. "투자자별 매매동향" 화면
3. 투자자 구분: 외국인 + 기관계
4. 기간: 최근 6개월
5. 하단 `[파일저장]` → `CSV` 선택
6. 저장 위치: `screener/data/hts_raw/flows/`

---

### 미래에셋 (카이로스/엠스탁)

#### 1. 일봉 시세
1. HTS 실행 → `주식` → `일별시세`
2. 종목 선택
3. 기간: 6개월 이상
4. 우클릭 → `[파일저장]` → `CSV`
5. 저장 위치: `screener/data/hts_raw/prices/`

#### 2. 수급
1. HTS 실행 → `투자자별 매매동향`
2. 기간 선택
3. `[파일저장]` → `CSV`
4. 저장 위치: `screener/data/hts_raw/flows/`

---

## 🔄 HTS CSV 변환 실행

```bash
# 일봉 변환
python tools/convert_hts_prices.py

# 수급 변환
python tools/convert_hts_flows.py
```

**출력 예시:**
```
📄 처리중: HTS_daily_prices_202601.csv

✅ 변환 완료!
   출력: screener/data/raw/prices_daily.csv
   행 수: 15,000
   종목 수: 50
   기간: 2025-07-01 ~ 2026-01-20
```

---

## 🎯 월간 운용 루틴 (30분)

### 월초 (1~5일)
```bash
# 1. HTS에서 CSV 다운로드 (10분)
# 2. CSV 변환 (2분)
python tools/convert_hts_prices.py
python tools/convert_hts_flows.py

# 3. 뉴스 입력 (5분)
# screener/data/raw/news_events.csv 편집

# 4. 스크리너 실행 (2분)
cd screener
python main_monthly.py

# 5. 결과 확인 (5분)
# screener/data/output/candidates_202601.csv
```

---

### 월중 (6~20일)
- 주 1회 프론트엔드 확인
- 조정 구간에서 분할 진입

---

### 월말 (21~말일)
- +15% → 30% 익절
- +25% → 추가 30% 익절
- 잔량 → 20일선 이탈 시 정리

---

## 🐛 문제 해결

### API 연결 오류
```
❌ API Error: Failed to fetch
```
**해결:**
1. 백엔드 서버 실행 여부 확인
2. `http://127.0.0.1:8125` 접속 테스트
3. API 키 일치 여부 확인

---

### CSV 변환 오류
```
⚠️ HTS 가격 CSV 파일이 없습니다.
```
**해결:**
1. HTS CSV 파일이 올바른 폴더에 있는지 확인
2. 파일 인코딩이 `cp949` (ANSI)인지 확인
3. 컬럼명이 매핑 테이블과 일치하는지 확인

---

### 스크리너 데이터 없음
```
[MarketGate OFF] reason={'reason': 'risk_off_ma20_down'}
```
**정상 동작입니다.** 시장이 RISK_OFF 상태일 때는 신규 진입을 금지합니다.

---

## 📞 추가 도움말

- **README.md**: 전체 시스템 개요
- **backend/server.py**: API 엔드포인트 상세
- **screener/main_monthly.py**: 스크리너 로직 상세

---

## ⚠️ 주의사항

1. **투자 권유 아님**: 교육 및 연구 목적
2. **손실 책임**: 사용자에게 있음
3. **목업 데이터**: 백엔드는 샘플 데이터 반환
4. **실전 사용 시**: 실제 HTS 데이터 필수

---

## 🎓 다음 단계

1. **FREE 플랜으로 시작**: 기본 기능 익히기
2. **실제 CSV 수집**: HTS에서 데이터 다운로드
3. **스크리너 실행**: 월 1회 루틴 연습
4. **PRO/ELITE 업그레이드**: Trade Plan 활용

---

**Happy Trading! 📊🚀**
