# 🔍 한국투자증권 API 연결 문제 해결 가이드

## 🚨 현재 상황
- ✅ 미국 주식 (Yahoo Finance): 정상 작동
- ❌ 한국 주식 (한국투자증권 API): 연결 실패

---

## 📋 단계별 진단 방법

### Step 1: API 키 확인
```bash
cd backend
cat .env
```

**확인 사항:**
- `KIS_APP_KEY` 값이 설정되어 있는가?
- `KIS_APP_SECRET` 값이 설정되어 있는가?
- 값에 공백이나 따옴표가 없는가?

**현재 .env 파일:**
```
KIS_APP_KEY=PSVPqsYslqRmx7N9ljFmRqhZaxuvGvirVPir
KIS_APP_SECRET=614neRBEBcVch8Gbw1NZicylNBxF0qDfJCw1LtTdqGbQ1cusv08QhyHO02ZSjj94iIETT6J1wFTGHIs4QbCVGkGWvluSqDaaPLOSjokXx7XdnorXRZMieEUOB4UO3D2bv5mcwYbNFU2dM28FV1NQsoYWK5kYNts4zzh+6kycuLmUdEDbqWg=
```

✅ **형식은 올바름**

---

### Step 2: API 연결 테스트

```bash
cd backend
python test_kis_api.py
```

**예상 출력 (성공 시):**
```
============================================================
한국투자증권 API 연결 테스트
============================================================

1. API 인스턴스 생성 중...
   ✅ 인스턴스 생성 완료

2. API 키 확인...
   KIS_APP_KEY: PSVPqsYslq... (총 38자)
   KIS_APP_SECRET: 614neRBEBc... (총 174자)

3. Access Token 발급 중...
   ✅ 토큰 발급 성공: eyJ0eXAiOiJKV1QiLCJ...

4. 삼성전자 (005930) 현재가 조회 중...
   ✅ 조회 성공!
   종목명: 삼성전자
   현재가: 75,200원
   등락률: +1.50%
   거래량: 12,345,678주

5. LIG넥스원 (079550) 현재가 조회 중...
   ✅ 조회 성공!
   종목명: LIG넥스원
   현재가: 544,500원
   등락률: +2.30%

============================================================
✅ 모든 테스트 통과!
한국투자증권 API 연결이 정상적으로 작동합니다.
============================================================
```

**예상 출력 (실패 시):**
실제 에러 메시지를 확인해야 원인을 파악할 수 있습니다.

---

### Step 3: 일반적인 에러 원인 및 해결

#### ❌ 에러 1: "Invalid API key"
**원인:** API 키 또는 시크릿이 잘못됨

**해결:**
1. 한국투자증권 API 포털 접속
2. 내 애플리케이션 → 상세보기
3. API 키와 시크릿 복사
4. `.env` 파일 업데이트

---

#### ❌ 에러 2: "Unauthorized" (401)
**원인:** 
- API 키가 만료됨
- 앱 상태가 비활성화됨

**해결:**
1. API 포털에서 앱 상태 확인
2. "운영" 상태인지 확인
3. 필요시 새 API 키 발급

---

#### ❌ 에러 3: "Forbidden" (403)
**원인:** 
- IP 제한
- API 사용 권한 없음

**해결:**
1. API 포털 → 내 애플리케이션 → IP 관리
2. 현재 IP 주소 추가 또는 "전체 허용" 설정
3. API 권한 확인 (주식 시세 조회 권한 필요)

---

#### ❌ 에러 4: "Rate limit exceeded"
**원인:** API 호출 횟수 초과 (분당 20회 제한)

**해결:**
- 잠시 대기 후 재시도
- scheduler.py에서 종목 수 줄이기 (테스트용)

---

#### ❌ 에러 5: "Connection timeout"
**원인:** 
- 네트워크 문제
- 방화벽 차단

**해결:**
1. 인터넷 연결 확인
2. 방화벽에서 `openapi.koreainvestment.com` 허용
3. 프록시 설정 확인

---

#### ❌ 에러 6: "Market closed"
**원인:** 장 마감 시간 (오후 3:30 이후)

**해결:**
- 정상 동작 (오후 6시 자동 업데이트는 전일 종가 사용)
- `get_current_price`는 장 시간에만 정확한 시세 제공

---

### Step 4: API 키 재발급 (필요 시)

#### 한국투자증권 API 포털
https://apiportal.koreainvestment.com/

#### 절차:
1. 로그인
2. **내 애플리케이션** 메뉴
3. 기존 앱 선택 또는 새 앱 등록
4. **API KEY 발급** 클릭
5. 새 API Key와 Secret 복사
6. `backend/.env` 파일 업데이트:
   ```
   KIS_APP_KEY=새_키_여기
   KIS_APP_SECRET=새_시크릿_여기
   ```

---

### Step 5: 실전 모드 vs 모의투자 모드

한국투자증권 API는 두 가지 모드가 있습니다:

#### 실전 모드
- URL: `https://openapi.koreainvestment.com:9443`
- 실제 계좌 연동
- **현재 사용 중** ✅

#### 모의투자 모드
- URL: `https://openapivts.koreainvestment.com:9443`
- 가상 계좌
- 테스트용

**확인 방법:**
```python
# backend/services/korea_investment_api.py
self.base_url = "https://openapi.koreainvestment.com:9443"  # 실전
# 또는
self.base_url = "https://openapivts.koreainvestment.com:9443"  # 모의
```

---

## 🔧 빠른 해결 방법

### 방법 1: 테스트 스크립트 실행
```bash
cd backend
python test_kis_api.py
```

→ 에러 메시지를 확인하고 위의 Step 3에서 해당 에러 찾기

---

### 방법 2: 수동으로 API 키 재입력

새 API 키를 받으셨다면:

1. `backend/.env` 파일 열기
2. 아래 형식으로 수정:
   ```
   KIS_APP_KEY=새로받은키
   KIS_APP_SECRET=새로받은시크릿
   ```
3. 서버 재시작
4. 테스트 재실행

---

### 방법 3: 임시로 한국 주식 제외

한국투자증권 API 문제가 계속되면:

```python
# backend/scheduler.py

STOCK_LIST = {
    "US": [
        {"ticker": "LMT", "name": "Lockheed Martin"},
        {"ticker": "JNJ", "name": "Johnson & Johnson"}
    ],
    "KR": [
        # 임시로 주석 처리
        # {"ticker": "012450", "name": "한화에어로스페이스"},
        # {"ticker": "079550", "name": "LIG넥스원"},
    ]
}
```

→ 미국 주식만으로 우선 운영 가능

---

## 📊 현재 상태 요약

| 항목 | 상태 | 비고 |
|------|------|------|
| API 키 설정 | ✅ 완료 | .env 파일 확인 |
| 미국 주식 (Yahoo) | ✅ 작동 | LMT, JNJ 조회 가능 |
| 한국 주식 (KIS API) | ❌ 실패 | 원인 진단 필요 |
| 스케줄러 | ✅ 구현 | 코드 완성 |
| 프론트엔드 | ✅ 구현 | JSON 로더 완성 |

---

## 🎯 다음 단계

1. **테스트 실행:**
   ```bash
   cd backend
   python test_kis_api.py
   ```

2. **에러 메시지 확인:**
   - 구체적인 에러 내용을 알려주시면 정확한 해결책 제시 가능

3. **API 키 재발급:**
   - 필요하다면 새 API 키를 발급받아 제공 가능

---

## 💬 에러 메시지 보고 양식

아래 정보를 알려주시면 정확한 해결을 도와드리겠습니다:

```
1. 테스트 스크립트 실행 결과:
   $ python test_kis_api.py
   [여기에 출력 내용 붙여넣기]

2. 에러 메시지:
   [구체적인 에러 내용]

3. API 포털 상태:
   - 앱 상태: [운영/개발/중지]
   - IP 설정: [특정 IP/전체 허용]
   - API 권한: [어떤 권한이 활성화되어 있는지]

4. 기타:
   - 새 API 키가 필요한가요? (Y/N)
   - 모의투자 모드로 변경할까요? (Y/N)
```

---

> **작성일:** 2026-01-21  
> **상태:** 진단 대기 중  
> **다음:** test_kis_api.py 실행 결과 확인
