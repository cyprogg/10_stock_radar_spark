# 📊 실시간 주가 연동 문제 및 해결 방안

## 🚨 현재 문제점

### 하드코딩된 주가 데이터
현재 시스템은 **JavaScript 파일 내부에 주가를 직접 입력**하는 방식으로 작동합니다.

```javascript
// 현재 방식 (하드코딩)
'방산': [
    { ticker: 'LMT', name: 'Lockheed Martin', price: 581.00 },  // 수동 업데이트 필요
    { ticker: '012450', name: '한화에어로스페이스', price: 185000 },
    { ticker: '079550', name: 'LIG넥스원', price: 544000 }  // 수동 업데이트 필요
]
```

### 문제점
- ❌ 실시간 시세 반영 불가
- ❌ 주가 변동 시 매번 수동 수정 필요
- ❌ 사용자가 최신 시세를 볼 수 없음
- ❌ 오래된 데이터로 잘못된 매매 계획 생성 가능

---

## 💡 해결 방안 (3가지 옵션)

### 옵션 1: 백엔드 API 연동 (권장) ⭐⭐⭐⭐⭐

#### 장점
- ✅ 실시간 주가 자동 업데이트
- ✅ 정확한 시세 보장
- ✅ 한국투자증권 API 활용 가능 (이미 .env에 설정됨)
- ✅ 미국 주식은 Alpha Vantage 또는 Yahoo Finance API

#### 구현 방법
```javascript
// 프론트엔드에서 백엔드 API 호출
async function loadStockPrice(ticker, market) {
    try {
        const response = await fetch(`/api/price/${ticker}?market=${market}&key=ds-test-2026`);
        const data = await response.json();
        return data.currentPrice;
    } catch (error) {
        console.error('주가 조회 실패:', error);
        return null;
    }
}

// 종목 선택 시 실시간 주가 조회
async function handleStockChange() {
    const ticker = document.getElementById('stock').value;
    const market = document.querySelector('input[name="market"]:checked').value;
    
    const price = await loadStockPrice(ticker, market);
    if (price) {
        document.getElementById('current-price').value = price;
    }
}
```

#### 백엔드 구현 (backend/server.py)
```python
@app.get("/api/price/{ticker}")
async def get_stock_price(ticker: str, market: str = "KR", key: str = Query(...)):
    verify_key(key)
    
    if market == "US":
        # Alpha Vantage 또는 Yahoo Finance API
        price = get_us_stock_price(ticker)
    else:
        # 한국투자증권 API
        price = get_kr_stock_price(ticker)
    
    return {
        "ticker": ticker,
        "market": market,
        "currentPrice": price,
        "timestamp": datetime.now().isoformat()
    }
```

#### 필요 작업
1. ✅ backend/server.py에 `/api/price/{ticker}` 엔드포인트 추가
2. ✅ 한국투자증권 API 연동 (KIS_APP_KEY 활용)
3. ✅ Alpha Vantage API 키 발급 (무료)
4. ✅ 프론트엔드에서 API 호출 로직 추가

---

### 옵션 2: 외부 API 직접 호출 (중간) ⭐⭐⭐

#### 장점
- ✅ 백엔드 없이 프론트엔드만으로 구현 가능
- ✅ 비교적 빠른 구현

#### 단점
- ⚠️ CORS 문제 발생 가능
- ⚠️ API 키 노출 위험
- ⚠️ 한국투자증권 API는 서버 필요

#### 구현 방법 (미국 주식만 가능)
```javascript
// Yahoo Finance 무료 API (CORS 우회 프록시 필요)
async function getUSStockPrice(ticker) {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${ticker}`;
    try {
        const response = await fetch(url);
        const data = await response.json();
        const price = data.chart.result[0].meta.regularMarketPrice;
        return price;
    } catch (error) {
        console.error('주가 조회 실패:', error);
        return null;
    }
}
```

#### 문제점
- ❌ 한국 주식은 백엔드 없이 불가능
- ❌ CORS 에러 발생 가능

---

### 옵션 3: 수동 업데이트 + 업데이트 날짜 표시 (임시) ⭐⭐

#### 장점
- ✅ 추가 개발 불필요
- ✅ 현재 시스템 유지

#### 개선 방법
```javascript
const STOCK_DATABASE = {
    meta: {
        lastUpdate: '2026-01-21 17:00',  // 마지막 업데이트 시간
        note: '주가는 수동으로 업데이트됩니다.'
    },
    '방산': [
        { ticker: 'LMT', name: 'Lockheed Martin', price: 581.00, updated: '2026-01-21' },
        { ticker: '079550', name: 'LIG넥스원', price: 544000, updated: '2026-01-21' }
    ]
};
```

#### UI에 경고 표시
```html
<div class="alert warning">
    ⚠️ 주가 데이터는 2026-01-21 17:00 기준입니다. 
    실제 매매 전 최신 시세를 확인하세요.
</div>
```

---

## 🎯 권장 솔루션: 옵션 1 (백엔드 API 연동)

### 이유
1. ✅ 한국투자증권 API 키가 이미 .env에 설정되어 있음
2. ✅ backend/server.py가 이미 존재
3. ✅ 가장 정확하고 안정적인 방법
4. ✅ 향후 확장 가능 (실시간 차트, 뉴스 등)

### 구현 로드맵

#### Phase 1: 백엔드 API 추가 (30분)
- [ ] `/api/price/{ticker}` 엔드포인트 구현
- [ ] 한국투자증권 API 연동 (한국 주식)
- [ ] Yahoo Finance API 연동 (미국 주식)

#### Phase 2: 프론트엔드 연동 (20분)
- [ ] `loadStockPrice()` 함수 추가
- [ ] `handleStockChange()` 수정
- [ ] 로딩 인디케이터 추가

#### Phase 3: 테스트 (10분)
- [ ] LMT 주가 실시간 조회 테스트
- [ ] LIG넥스원 주가 실시간 조회 테스트
- [ ] 에러 처리 테스트

---

## 📋 즉시 수정 완료 사항

### ✅ 수동 주가 업데이트 완료

#### 미국 주식
```javascript
LMT (Lockheed Martin):
❌ 이전: $497.00
✅ 현재: $581.00 (2026-01-21 업데이트)
```

#### 한국 주식
```javascript
LIG넥스원 (079550):
❌ 이전: ₩95,000
✅ 현재: ₩544,000 (2026-01-21 업데이트)
```

#### 수정된 파일
- ✅ `trade_plan_simulation.html` - LMT, LIG넥스원 주가 수정
- ✅ `market_driven_plan.html` - LMT 주가 수정

---

## 🧪 테스트 방법

### Test 1: LMT 주가 확인
1. **trade_plan_simulation.html** 열기
2. 시장: **US** 선택
3. 섹터: **방산**
4. 종목: **Lockheed Martin (LMT)** 선택
5. ✅ 현재 주가: `581.00` 표시 확인

### Test 2: LIG넥스원 주가 확인
1. 시장: **KR** 선택
2. 섹터: **방산**
3. 종목: **LIG넥스원 (079550)** 선택
4. ✅ 현재 주가: `544000` 표시 확인

---

## 💬 다음 단계 결정

사용자님께서 선택하실 수 있습니다:

### 선택 1: 실시간 주가 연동 구현 (권장) ⭐
- 백엔드 API 개발 (~1시간)
- 한국투자증권 + Yahoo Finance 연동
- 완전 자동화

### 선택 2: 현재 상태 유지
- 필요 시 수동으로 주가 업데이트
- 빠른 시작 가능
- 개발 불필요

### 선택 3: 혼합 방식
- 미국 주식만 실시간 연동
- 한국 주식은 수동 업데이트

---

## 📊 현재 주가 데이터베이스 (2026-01-21 기준)

### 미국 주식
```
LMT (Lockheed Martin): $581.00 ✅
JNJ (Johnson & Johnson): $215.00
```

### 한국 주식
```
방산:
- 한화에어로스페이스 (012450): ₩185,000
- LIG넥스원 (079550): ₩544,000 ✅

반도체:
- 삼성전자 (005930): ₩75,000
- SK하이닉스 (000660): ₩142,000

헬스케어:
- 삼성바이오로직스 (207940): ₩850,000
- 셀트리온 (068270): ₩175,000
```

---

## 🎉 결론

✅ **주가 수정 완료:** LMT $581.00, LIG넥스원 ₩544,000  
⚠️ **근본 문제:** 실시간 주가 연동 필요  
💡 **권장 방안:** 백엔드 API 연동 (옵션 1)

---

> **작성일:** 2026-01-21  
> **상태:** 수동 수정 완료 / 실시간 연동 대기 중  
> **다음 단계:** 사용자 결정 필요
