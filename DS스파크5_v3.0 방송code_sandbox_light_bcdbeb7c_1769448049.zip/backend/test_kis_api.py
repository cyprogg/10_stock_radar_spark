"""
한국투자증권 API 연결 테스트
"""
import sys
import os

# 현재 디렉토리를 Python 경로에 추가
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.korea_investment_api import KoreaInvestmentAPI

def test_kis_connection():
    """한국투자증권 API 연결 테스트"""
    print("=" * 60)
    print("한국투자증권 API 연결 테스트")
    print("=" * 60)
    print()
    
    try:
        # API 인스턴스 생성
        print("1. API 인스턴스 생성 중...")
        api = KoreaInvestmentAPI()
        print("   ✅ 인스턴스 생성 완료")
        print()
        
        # API 키 확인
        print("2. API 키 확인...")
        print(f"   KIS_APP_KEY: {api.app_key[:10]}... (총 {len(api.app_key)}자)")
        print(f"   KIS_APP_SECRET: {api.app_secret[:10]}... (총 {len(api.app_secret)}자)")
        print()
        
        # 토큰 발급 테스트
        print("3. Access Token 발급 중...")
        token = api.get_token()
        print(f"   ✅ 토큰 발급 성공: {token[:20]}...")
        print()
        
        # 삼성전자 현재가 조회 테스트
        print("4. 삼성전자 (005930) 현재가 조회 중...")
        samsung = api.get_current_price('005930')
        print(f"   ✅ 조회 성공!")
        print(f"   종목명: {samsung['name']}")
        print(f"   현재가: {samsung['price']:,}원")
        print(f"   등락률: {samsung['change']:+.2f}%")
        print(f"   거래량: {samsung['volume']:,}주")
        print()
        
        # LIG넥스원 조회 테스트
        print("5. LIG넥스원 (079550) 현재가 조회 중...")
        lig = api.get_current_price('079550')
        print(f"   ✅ 조회 성공!")
        print(f"   종목명: {lig['name']}")
        print(f"   현재가: {lig['price']:,}원")
        print(f"   등락률: {lig['change']:+.2f}%")
        print()
        
        print("=" * 60)
        print("✅ 모든 테스트 통과!")
        print("한국투자증권 API 연결이 정상적으로 작동합니다.")
        print("=" * 60)
        
        return True
        
    except Exception as e:
        print()
        print("=" * 60)
        print("❌ 테스트 실패!")
        print(f"에러: {e}")
        print()
        print("문제 해결 방법:")
        print("1. .env 파일의 API 키와 시크릿을 확인하세요")
        print("2. 한국투자증권 API 포털에서 앱 상태를 확인하세요")
        print("3. IP가 허용 목록에 있는지 확인하세요")
        print("4. API 사용 권한이 활성화되어 있는지 확인하세요")
        print("=" * 60)
        
        # 상세 에러 정보
        import traceback
        print("\n상세 에러 정보:")
        print(traceback.format_exc())
        
        return False

if __name__ == "__main__":
    test_kis_connection()
