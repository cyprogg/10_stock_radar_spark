#!/usr/bin/env python3
"""
DS-Anchor 시스템 테스트
각 단계를 개별적으로 테스트하여 문제를 진단합니다.
"""

import sys
import subprocess
import requests
from pathlib import Path

def test_api_server():
    """API 서버 테스트"""
    print("1️⃣ API 서버 테스트...")
    try:
        url = "http://127.0.0.1:8125/regime?key=ds-test-2026"
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        data = response.json()
        print(f"   ✅ API 응답 정상: {data.get('state', 'N/A')}")
        return True
    except Exception as e:
        print(f"   ❌ API 서버 오류: {e}")
        print("   → python server_v2.py 실행 필요")
        return False

def test_script_generation():
    """대본 생성 테스트"""
    print("2️⃣ 대본 생성 테스트...")
    try:
        url = "http://127.0.0.1:8125/generate_ds_anchor_script?key=ds-test-2026"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        script = response.json().get("script", "")
        
        if not script:
            print("   ❌ 대본이 비어있습니다.")
            return False
        
        with open("test_script.txt", "w", encoding="utf-8") as f:
            f.write(script)
        
        print(f"   ✅ 대본 생성 완료 ({len(script)} 글자)")
        print(f"   → test_script.txt 저장됨")
        return True
    except Exception as e:
        print(f"   ❌ 대본 생성 오류: {e}")
        return False

def test_tts():
    """음성 합성 테스트"""
    print("3️⃣ 음성 합성 테스트...")
    
    # 테스트 텍스트 생성
    test_text = "안녕하세요. Decision Stream 시스템 테스트입니다."
    with open("test_tts.txt", "w", encoding="utf-8") as f:
        f.write(test_text)
    
    try:
        subprocess.run([
            "edge-tts",
            "--voice", "ko-KR-InJoonNeural",
            "--file", "test_tts.txt",
            "--write-media", "test_voice.mp3"
        ], check=True, capture_output=True)
        
        if Path("test_voice.mp3").exists():
            size = Path("test_voice.mp3").stat().st_size
            print(f"   ✅ 음성 합성 완료 ({size / 1024:.1f}KB)")
            print(f"   → test_voice.mp3 생성됨")
            return True
        else:
            print("   ❌ 음성 파일이 생성되지 않았습니다.")
            return False
    except Exception as e:
        print(f"   ❌ 음성 합성 오류: {e}")
        print("   → pip install edge-tts")
        return False

def test_screenshot():
    """대시보드 스크린샷 테스트"""
    print("4️⃣ 대시보드 스크린샷 테스트...")
    try:
        subprocess.run(
            ["python", "capture_dashboard.py"],
            check=True,
            capture_output=True
        )
        
        # 생성된 파일 확인
        output_dir = Path("output")
        screenshots = list(output_dir.glob("dashboard_*.png"))
        
        if screenshots:
            latest = max(screenshots, key=lambda p: p.stat().st_mtime)
            size = latest.stat().st_size
            print(f"   ✅ 스크린샷 완료 ({size / 1024:.1f}KB)")
            print(f"   → {latest.name}")
            return True
        else:
            print("   ❌ 스크린샷 파일이 생성되지 않았습니다.")
            return False
    except Exception as e:
        print(f"   ❌ 스크린샷 오류: {e}")
        print("   → playwright install chromium")
        return False

def test_ffmpeg():
    """FFmpeg 테스트"""
    print("5️⃣ FFmpeg 테스트...")
    try:
        result = subprocess.run(
            ["ffmpeg", "-version"],
            check=True,
            capture_output=True,
            text=True
        )
        version_line = result.stdout.split('\n')[0]
        print(f"   ✅ FFmpeg 설치됨: {version_line}")
        return True
    except FileNotFoundError:
        print("   ❌ FFmpeg가 설치되지 않았습니다.")
        print("   Ubuntu/Debian: sudo apt install ffmpeg")
        print("   macOS: brew install ffmpeg")
        return False
    except Exception as e:
        print(f"   ❌ FFmpeg 오류: {e}")
        return False

def test_video_creation():
    """영상 생성 테스트 (간단 버전)"""
    print("6️⃣ 영상 생성 테스트...")
    
    # 필요 파일 확인
    output_dir = Path("output")
    screenshots = list(output_dir.glob("dashboard_*.png"))
    voice_file = Path("test_voice.mp3")
    
    if not screenshots:
        print("   ⏭️  스크린샷이 없어 건너뜁니다.")
        return True
    
    if not voice_file.exists():
        print("   ⏭️  음성 파일이 없어 건너뜁니다.")
        return True
    
    try:
        latest_screenshot = max(screenshots, key=lambda p: p.stat().st_mtime)
        test_video = "test_video.mp4"
        
        subprocess.run([
            "ffmpeg", "-y",
            "-loop", "1", "-i", str(latest_screenshot),
            "-i", "test_voice.mp3",
            "-c:v", "libx264",
            "-tune", "stillimage",
            "-c:a", "aac",
            "-b:a", "192k",
            "-pix_fmt", "yuv420p",
            "-shortest",
            "-t", "5",  # 5초만 테스트
            test_video
        ], check=True, capture_output=True)
        
        if Path(test_video).exists():
            size = Path(test_video).stat().st_size
            print(f"   ✅ 영상 생성 완료 ({size / 1024:.1f}KB)")
            print(f"   → {test_video}")
            return True
        else:
            print("   ❌ 영상 파일이 생성되지 않았습니다.")
            return False
    except Exception as e:
        print(f"   ❌ 영상 생성 오류: {e}")
        return False

def main():
    """테스트 실행"""
    print("🧪 DS-Anchor 시스템 테스트")
    print("=" * 60)
    print()
    
    results = []
    
    # 각 테스트 실행
    results.append(("API 서버", test_api_server()))
    results.append(("대본 생성", test_script_generation()))
    results.append(("음성 합성", test_tts()))
    results.append(("스크린샷", test_screenshot()))
    results.append(("FFmpeg", test_ffmpeg()))
    results.append(("영상 생성", test_video_creation()))
    
    # 결과 요약
    print()
    print("=" * 60)
    print("📊 테스트 결과")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✅" if result else "❌"
        print(f"{status} {name}")
    
    print()
    print(f"총 {passed}/{total} 테스트 통과")
    
    if passed == total:
        print()
        print("🎉 모든 테스트 통과! 시스템이 정상입니다.")
        print()
        print("실행 방법:")
        print("  python ds_anchor_auto.py KR")
        return 0
    else:
        print()
        print("⚠️  일부 테스트 실패. 위의 오류 메시지를 확인하세요.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
